package com.test.ardh.ui

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.test.ardh.R
import com.test.ardh.ui.store.StoreFragment
import com.test.ardh.ui.favorite.FavoriteFragment
import com.test.ardh.ui.product.ProductFragment
import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bottom_navigation.setOnNavigationItemSelectedListener { item ->
            when (item.itemId) {
                R.id.store -> {
                    loadStore(savedInstanceState)
                }
                R.id.product -> {
                    loadProduct(savedInstanceState)
                }
                R.id.like -> {
                    loadFavorite(savedInstanceState)
                }
            }
            true
        }
        bottom_navigation.selectedItemId = R.id.store
    }

    private fun loadStore(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(
                    R.id.main_container,
                    StoreFragment(),
                    StoreFragment::class.java.simpleName
                )
                .commit()
        }
    }

    private fun loadProduct(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(
                    R.id.main_container,
                    ProductFragment(),
                    ProductFragment::class.java.simpleName
                )
                .commit()
        }
    }


    private fun loadFavorite(savedInstanceState: Bundle?) {
        if (savedInstanceState == null) {
            supportFragmentManager.beginTransaction()
                .replace(
                    R.id.main_container,
                    FavoriteFragment(),
                    FavoriteFragment::class.java.simpleName
                )
                .commit()
        }
    }
}