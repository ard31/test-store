package com.test.ardh.ui.login

import android.annotation.SuppressLint
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.EditText
import com.test.ardh.R
import com.test.ardh.ui.MainActivity
import kotlinx.android.synthetic.main.activity_login.*

class LoginActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)

        addTextWatcher(etPhoneNumber)
        addTextWatcher(etPinNumber)
        actionLogin()
    }


    private fun actionLogin() {

        btnLogin.setOnClickListener {
            val intent = Intent(this, MainActivity::class.java)
            startActivity(intent)
        }

    }

    private fun addTextWatcher(input: EditText) {
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun onTextChanged(charSequence: CharSequence, i: Int, i1: Int, i2: Int) {
            }

            override fun afterTextChanged(editable: Editable) {
                validationLogin()
            }
        })
    }

    @SuppressLint("UseCompatLoadingForDrawables")
    private fun validationLogin() {

        if (etPhoneNumber.text.toString().isNotEmpty() && etPinNumber.text.toString().isNotEmpty()) {
            btnLogin.isEnabled = true
            btnLogin.background = resources.getDrawable(R.drawable.bg_button_blue, null)
        } else {
            btnLogin.isEnabled = false
            btnLogin.background = resources.getDrawable(R.drawable.bg_button_grey, null)
        }
    }
}