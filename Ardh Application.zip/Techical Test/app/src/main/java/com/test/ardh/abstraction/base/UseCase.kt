package com.test.ardh.abstraction.base

abstract class UseCase<T> {
    abstract fun execute(): T
}